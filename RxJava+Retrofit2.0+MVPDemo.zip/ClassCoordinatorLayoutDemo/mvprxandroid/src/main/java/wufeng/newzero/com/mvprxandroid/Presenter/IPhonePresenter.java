package wufeng.newzero.com.mvprxandroid.Presenter;

/**
 * Created by wufeng on 6/27/16.
 */
public interface IPhonePresenter {
    void  getPhoneDate(String apikey,String phone);
}

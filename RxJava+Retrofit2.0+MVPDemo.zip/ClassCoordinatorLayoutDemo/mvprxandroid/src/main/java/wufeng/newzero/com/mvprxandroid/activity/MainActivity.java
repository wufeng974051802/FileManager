package wufeng.newzero.com.mvprxandroid.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import wufeng.newzero.com.mvprxandroid.Presenter.PhonePresenteImp;
import wufeng.newzero.com.mvprxandroid.R;
import wufeng.newzero.com.mvprxandroid.bean.PhoneResult;
import wufeng.newzero.com.mvprxandroid.view.PhoneView;


public class MainActivity extends AppCompatActivity implements PhoneView {

    private Context context;
    private Button mtvShow;
    private ProgressDialog mProgressDialog;
    private PhonePresenteImp mPhonePresenter;

    private static  final String API_KEY = "8e13586b86e4b7f3758ba3bd6c9c9135";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        mPhonePresenter = new PhonePresenteImp(this);
        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setMessage("lodeing");

        mtvShow= (Button) findViewById(R.id.button);
        mtvShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               mPhonePresenter.getPhoneDate(API_KEY,"15210011578");
            }
        });

    }


    @Override
    public void loadPhoneimage(PhoneResult PhoneBean) {
        mtvShow.setText(PhoneBean.getRetData().getPhone());
    }

    @Override
    public void ShowProgressDialog() {
       mProgressDialog.show();

    }

    @Override
    public void hideProgressDialog() {
        mProgressDialog.hide();
    }
}

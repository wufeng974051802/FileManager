package wufeng.newzero.com.mvprxandroid.api;


import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Query;
import rx.Observable;
import wufeng.newzero.com.mvprxandroid.bean.PhoneResult;

/**
 * Created by wufeng on 6/27/16.
 */
public interface ApiManagerService {
    @GET("/apistore/mobilenumber/mobilenumber")
    Observable<PhoneResult> getResult(@Header("apikey")String apikey, @Query("phone")String phone);
}

package wufeng.newzero.com.mvprxandroid.Model;



import rx.android.schedulers.AndroidSchedulers;



import rx.functions.Action1;
import rx.schedulers.Schedulers;
import wufeng.newzero.com.mvprxandroid.api.ApiManager;
import wufeng.newzero.com.mvprxandroid.bean.PhoneResult;

/**
 * Created by wufeng on 6/27/16.
 */
public class PhoneModelImp implements IPhoneModel{
    private  PhoneDataOnListener mPhoneDataOnListener;

    public PhoneModelImp(PhoneDataOnListener mPhoneDataOnListener) {
        this.mPhoneDataOnListener = mPhoneDataOnListener;
    }

    @Override
    public void getPhoneDate(String apikey, String phone) {
        ApiManager.getResult(apikey,phone)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<PhoneResult>() {
                    @Override
                    public void call(PhoneResult phoneResult) {
                        mPhoneDataOnListener.onSuccess(phoneResult);
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                        mPhoneDataOnListener.OnFailure(throwable);
                    }
                });
    }


    public interface  PhoneDataOnListener{
        void  onSuccess(PhoneResult phoneBean);
        void  OnFailure(Throwable e);
    }



}

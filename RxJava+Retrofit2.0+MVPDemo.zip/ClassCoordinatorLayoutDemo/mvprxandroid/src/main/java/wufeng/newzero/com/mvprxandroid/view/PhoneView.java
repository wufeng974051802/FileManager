package wufeng.newzero.com.mvprxandroid.view;

import wufeng.newzero.com.mvprxandroid.bean.PhoneResult;

/**
 * Created by wufeng on 6/28/16.
 */
public interface PhoneView {
    void  loadPhoneimage(PhoneResult PhoneBean);
    void  ShowProgressDialog();
    void  hideProgressDialog();
}

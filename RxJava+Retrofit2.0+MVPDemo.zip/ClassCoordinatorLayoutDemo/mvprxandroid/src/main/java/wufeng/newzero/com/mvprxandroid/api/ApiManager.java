package wufeng.newzero.com.mvprxandroid.api;

;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import rx.Observable;
import wufeng.newzero.com.mvprxandroid.bean.PhoneResult;

/**
 * Created by wufeng on 6/27/16.
 */
public class ApiManager {
    private static  final String BASE_URL = "http://apis.baidu.com";
    //创建Retrofit对象
    private  static final  Retrofit sRetrofit = new Retrofit.Builder()
                                                .addConverterFactory(GsonConverterFactory.create())
                                                 .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                                                .baseUrl(BASE_URL)
                                                .build();
    private static final ApiManagerService apiManager = sRetrofit.create(ApiManagerService.class);

    //创建访问API的请求

    public static  Observable<PhoneResult> getResult(String apikey,String phone){
        return apiManager.getResult(apikey, phone);
    }





}

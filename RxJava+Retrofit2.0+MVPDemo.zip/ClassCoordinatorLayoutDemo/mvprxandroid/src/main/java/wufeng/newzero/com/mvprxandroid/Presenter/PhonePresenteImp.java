package wufeng.newzero.com.mvprxandroid.Presenter;

import wufeng.newzero.com.mvprxandroid.Model.IPhoneModel;
import wufeng.newzero.com.mvprxandroid.Model.PhoneModelImp;
import wufeng.newzero.com.mvprxandroid.bean.PhoneResult;
import wufeng.newzero.com.mvprxandroid.view.PhoneView;

/**
 * Created by wufeng on 6/28/16.
 */
public class PhonePresenteImp implements IPhonePresenter,PhoneModelImp.PhoneDataOnListener {
    private IPhoneModel mPhondeModel;
    private PhoneView mPhoneView;

    public PhonePresenteImp(PhoneView mPhoneView) {
        this.mPhoneView = mPhoneView;
        this.mPhondeModel = new PhoneModelImp(this);
    }

    @Override
    public void getPhoneDate(String apikey, String phone) {
        mPhoneView.ShowProgressDialog();
        mPhondeModel.getPhoneDate(apikey,phone);
    }

    @Override
    public void onSuccess(PhoneResult phoneBean) {
        mPhoneView.loadPhoneimage(phoneBean);
        mPhoneView.hideProgressDialog();
    }

    @Override
    public void OnFailure(Throwable e) {
        mPhoneView.hideProgressDialog();

    }
}

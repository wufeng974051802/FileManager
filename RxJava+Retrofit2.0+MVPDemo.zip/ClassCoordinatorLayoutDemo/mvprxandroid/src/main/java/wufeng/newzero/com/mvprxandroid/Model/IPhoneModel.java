package wufeng.newzero.com.mvprxandroid.Model;



/**
 * Created by wufeng on 6/27/16.
 */
public interface IPhoneModel {
    void  getPhoneDate(String apikey,String phone);
}
